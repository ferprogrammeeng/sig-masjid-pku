<div class="footer footer1">
      <div class="container">
        <div class="row">
          <div class="col-md-4 col-md-offset-4">
            <h4 class="white">Sistem Informasi Geografis Masjid</h4>
          <h3 class="white">Indonesia</h3>
          <ul class="list-inline">
            <li><a href="" class="link-footer">Beranda</a></li>
            <li><a href="" class="link-footer">Tentang</a></li>
          </ul>
          </div>
        </div>
      </div>
    </div>

    <script src="js/bootstrap.min.js"></script>
    <script src="js/bootstrap-hover-dropdown.js"></script>
    <script src="js/script.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
    <script src="js/datatable-bootstrap.js"></script>
    
  </body>
</html>