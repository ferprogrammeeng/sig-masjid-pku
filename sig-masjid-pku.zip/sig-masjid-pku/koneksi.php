<?php
$host = "localhost";
$user = "root";
$pass = "";
$name = "sig_masjid";
error_reporting(E_ALL ^ E_DEPRECATED);
$conn = mysqli_connect("localhost","root","","sig_masjid-pku");
mysqli_select_db($conn,"sig_masjid") or die("Tidak ada database yang dipilih!");
?>