-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 19 Des 2022 pada 18.21
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sig_masjid`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `masjid`
--

CREATE TABLE `masjid` (
  `id_masjid` int(8) NOT NULL,
  `nama_masjid` varchar(255) NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `alamat` text NOT NULL,
  `kota` varchar(50) NOT NULL,
  `provinsi` varchar(50) NOT NULL,
  `latitude` varchar(50) NOT NULL,
  `longitude` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `masjid`
--

INSERT INTO `masjid` (`id_masjid`, `nama_masjid`, `kategori`, `alamat`, `kota`, `provinsi`, `latitude`, `longitude`) VALUES
(1, 'Masjid Ath-Thohiriyah', 'Bangunan Masjid', 'Jl. Raya Pasinan Lemah Putih, Dusun Legundi, Krikilan, Kec. Driyorejo, Kabupaten Gresik, Jawa Timur 61177', 'Gresik', 'Jawa Timur', '-7.3870273', '112.5726754'),
(2, 'Masjid Al Baqo', 'Masjid', 'Jl. Raya Wates Tj., Wates, Kec. Wringinanom, Kabupaten Gresik, Jawa Timur 61176', 'Gresik', 'Jawa Timur', '-7.3748757', '112.5577748'),
(3, 'Masjid Al Ikhlas', 'Bangunan Masjid', 'Jl. Raya Krikilan No.555, Dusun Legundi, Krikilan, Kec. Driyorejo, Kabupaten Gresik, Jawa Timur 61177', 'Gresik', 'Jawa Timur', '-7.3847151', '112.5748535'),
(4, 'Masjid Sabilul Muttaqin', 'Bangunan Masjid', 'JL Raya Karangandong, Driyorejo, Dusun Larangan, Krikilan, Kec. Driyorejo, Kabupaten Gresik, Jawa Timur 61177', 'Gresik', 'Jawa Timur', '-7.3836833', '112.5761968'),
(5, 'Masjid As - Syuhada', 'Bangunan Masjid', 'Jrebeng, Sidomulyo, Kec. Krian, Kabupaten Sidoarjo, Jawa Timur 61262', 'Sidoarjo', 'Jawa Timur', '-7.3880775', '112.5768191'),
(6, 'Masjid Ar-Rohmah', 'Bangunan Masjid', 'Jl. Gubernur Sunandar, Jrebeng, Sidomulyo, Kec. Krian, Kabupaten Sidoarjo, Jawa Timur 61262', 'Sidoarjo', 'Jawa Timur', '-7.3902055', '112.5766796'),
(7, 'Masjid Al-Mubarok', 'Bangunan Masjid', 'Jalan abah toyib, Wringinanom, Jl. Raya Sumengko, Sidomoro Sidotompo, Sumengko, Kec. Wringinanom, Kabupaten Gresik, Jawa Timur 61176', 'Gresik', 'Jawa Timur', '-7.3949295', '112.5540847'),
(8, 'Masjid Abah Thoyyib Sumengko', 'Bangunan Masjid', 'Sidomoro Sidotompo, Sumengko, Kec. Wringinanom, Kabupaten Gresik, Jawa Timur 61176', 'Gresik', 'Jawa Timur', '-7.3949295', '112.5540847'),
(9, 'Masjid Nurah M. Ad Duraiby', 'Bangunan Masjid', 'Krajan, Lebanisuko, Kec. Wringinanom, Kabupaten Gresik, Jawa Timur 61176', 'Gresik', 'Jawa Timur', '-7.3883648', '112.545963');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `masjid`
--
ALTER TABLE `masjid`
  ADD PRIMARY KEY (`id_masjid`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `masjid`
--
ALTER TABLE `masjid`
  MODIFY `id_masjid` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
