<?php 
$title = "Tambahkan Data Masjid";
include_once "header.php";?>
<div class="row">
        <div class="col-md-12">
          <div class="panel panel-info panel-dashboard">
            <div class="panel-heading centered">
              <h2 class="panel-title"><strong> - <?php echo $title ?> - </strong></h2>
            </div>
            <div class="panel-body">
              <table class="table table-bordered table-striped table-admin">
              <thead>


<html>

<head>
	<title>Tambahkan Masjid</title>
</head>
 
<body>
	<a href="index.php">Beranda</a>
	<br/><br/>
 
	<form action="tambah.php" method="post" name="form1">
		<table width="25%" border="0">
			
			<tr> 
				<td>Nama Masjid</td>
				<td><input type="text" name="nama_masjid" required></td>
			</tr>
			<tr> 
				<td>Alamat</td>
				<td><input type="text" name="alamat" required></td>
			</tr>
				<tr> 
				<td>Kota</td>
				<td><input type="text" name="kota" required></td>
			</tr>
				<tr> 
				<td>Provinsi</td>
				<td><input type="text" name="provinsi" required></td>
			</tr>


			<tr> 
				<td>Latitude</td>
				<td><input type="text" name="latitude" required></td>
			</tr>
			<tr> 
				<td>Longitude</td>
				<td><input type="text" name="longitude" required></td>
			</tr>
			<tr> 
				<td></td>
				<td><input type="submit" name="Submit" value="Add"></td>
			</tr>
		</table>
	</form>
	
	<?php
 
	// Check If form submitted, insert form data into users table.
	if(isset($_POST['Submit'])) {
		
		$nama_masjid = $_POST['nama_masjid'];
		$alamat = $_POST['alamat'];
		$kota = $_POST['kota'];
		$provinsi = $_POST['provinsi'];
		$latitude = $_POST['latitude'];
		$longitude = $_POST['longitude'];
		
		// include database connection file
		include_once("koneksi.php");
				
		// Insert user data into table
		$koneksi = mysqli_query($conn,"INSERT INTO masjid(nama_masjid,alamat,kota,provinsi,latitude,longitude) VALUES('$nama_masjid','$alamat','$kota','$provinsi','$latitude','$longitude')");
		
		// Show message when user added
		echo "Masjid Berhasil di Tambahkan. <a href='data.php'>Lihat Data Masjid</a>";
	}
	?>
</body>
</html>
            </div>
          </div>
        </div>
        </div>
      </div>
    </div>
        
        </div>
      </div>
    </div>
<?php include_once "footer.php" ?>