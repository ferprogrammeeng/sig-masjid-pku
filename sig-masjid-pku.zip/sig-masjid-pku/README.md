# Sistem Informasi Geografis dengan PHP dan Google Maps API

Sistem Informasi Geografis Sederhana menggunakan MYSQL untuk menyimpan data longitude latitude diambil dari Google Maps API ditampilkan dalam single marker dan multiple marker

## Video Tutorial Step by Step Membuat SIG dengan Google Maps API
Ikuti penjelasan tiap baris kode di [Video ini](https://www.youtube.com/watch?v=3M2QnGjRAlc) via **YouTube**

## Subscribe Channel JuniorDev

[Junior Dev](https://www.youtube.com/c/juniordevindonesia) adalah sebuah channel tutorial komputer dan programmer mulai dari *HTML, CSS, PHP, SQL, Angular, Web Design* dan sebagainya. Di channel ini kamu bisa dapatkan tutorial gratis yang selalu update. Subscribe dan Like channel ini agar kamu bisa mengikuti terus tutorial-tutorialnya.

Jangan lupa follow untuk kontak, bertanya dan berdiskusi
* [Channel Youtube](https://www.youtube.com/c/juniordevindonesia)
* [Like Fanpage](https://www.facebook.com/juniordevindonesiaofficial/)
* [Twitter](http://twitter.com/hello_juniordev)
* [Instagram](https://www.instagram.com/juniordevindonesia/)
* [Google Plus](https://plus.google.com/+JuniorDevIndonesia/posts)
* [Email](mailto:hellojuniordev@gmail.com)

Jangan lupa [**SUBSCRIBE**](https://www.youtube.com/c/juniordevindonesia?sub_confirmation=1) ya..!

## Author
* **Sofyan Setiawan** - *Freelance Web Designer and Developer* - [Facebook](https://www.facebook.com/sofyansetiawanprofile) - [@sofyansetiawann](https://twitter.com/sofyansetiawann)